const Discord = require('discord.js');
const db = require('quick.db');

module.exports = {
    name: 'derank',
    aliases: [],

    run: async (client, message, args, prefix, color) => {
        let perm = false;

        message.member.roles.cache.forEach(role => {
            if (db.get(`ownerp_${message.guild.id}_${role.id}`)) {
                perm = true;
            }
        });

        if (client.config.owner.includes(message.author.id) || db.get(`ownermd_${client.user.id}_${message.author.id}`) === true || perm) {
            if (args[0]) {
                let user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

                if (!user) {
                    return message.channel.send(`Aucun membre trouvé pour : \`${args[0]}\``);
                }

                const boosterRoleID = '1122198609585258536';

                if (user.roles.highest.position > message.guild.me.roles.highest.position) {
                    return message.channel.send(`Je n'ai pas la permission de derank <@${user.id}>.`);
                }

                user.roles.cache.forEach(role => {
                    if (role.id !== boosterRoleID) {
                        user.roles.remove(role).catch(err => {
                            console.error(err);
                        });
                    }
                });

                message.channel.send(`${user} a été derank.`);
                let wass = db.get(`logmod_${message.guild.id}`);
                const logschannel = message.guild.channels.cache.get(wass);

                if (logschannel) {
                    logschannel.send(new Discord.MessageEmbed()
                        .setColor(color)
                        .setDescription(`${message.author} a derank ${user.user}`)
                    );
                }
            }
        } else {
            message.channel.send(`Vous n'avez pas la permission de faire cela.`);
        }
    }
};
